#pragma once
#include "GameObject.h"
#include "GraphicComponent.h"
#include "map"

//singleton
class GraphicComponentManager
{
	GraphicComponentManager() = default;
	~GraphicComponentManager() = default;
	
	GraphicComponentManager(const GraphicComponentManager&) = delete;
	const GraphicComponentManager& operator=(const GraphicComponentManager& other) = delete;

	static GraphicComponentManager* graphic_ptr;
	map<string, GraphicComponent*> graphics;

public:
	static GraphicComponentManager* getPtr();
	static void DeletePtr();

	void AddGraphic(GraphicComponent* lc);
	void DeleteGraphic(GraphicComponent* c);
	void DeleteGraphic(string ID);
	const string FindGraphic(GraphicComponent* c);
	GraphicComponent* FindGraphic(string ID);

	void Update();
};