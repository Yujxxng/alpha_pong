#include "EngineComponentManager.h"

EngineComponentManager* EngineComponentManager::engine_ptr = nullptr;


EngineComponentManager* EngineComponentManager::getPtr()
{
    if (engine_ptr == nullptr)
    {
        engine_ptr = new EngineComponentManager;

        return engine_ptr;
    }
    else
        return engine_ptr;
}

void EngineComponentManager::DeletePtr()
{
    if (engine_ptr != nullptr)
    {
        delete engine_ptr;
        engine_ptr = nullptr;
    }
}


void EngineComponentManager::AddEngine(EngineComponent* lc)
{

    engines.insert({ lc->GetOwner()->GetID(), lc});
}

void EngineComponentManager::DeleteEngine(EngineComponent* c)
{
    string key = FindEngine(c);

    if (key != "")
        engines.erase(key);
}

void EngineComponentManager::DeleteEngine(string ID)
{
    EngineComponent* tmp = FindEngine(ID);
    this->engines.erase(ID);

    //delete tmp;
}

const string EngineComponentManager::FindEngine(EngineComponent* c)
{
    for (auto it = engines.begin(); it != engines.end(); it++)
    {
        if (it->second == c)
        {
            //return it->first.substr(it->first.find(' '));
            return it->first;
        }
    }

    return "";
}

EngineComponent* EngineComponentManager::FindEngine(string ID)
{
    for (auto it = engines.begin(); it != engines.end(); it++)
    {
        GameObject* tmp = it->second->GetOwner();
        
        if (tmp->GetID() == ID)
            return it->second;
    }

    return nullptr;
}

void EngineComponentManager::Update()
{
    for (auto it = engines.begin(); it != engines.end(); it++)
    {
        it->second->Update();
    }
}
