#include "GraphicComponentManager.h"

GraphicComponentManager* GraphicComponentManager::graphic_ptr = nullptr;


GraphicComponentManager* GraphicComponentManager::getPtr()
{
    if (graphic_ptr == nullptr)
    {
        graphic_ptr = new GraphicComponentManager;

        return graphic_ptr;
    }
    else
        return graphic_ptr;
}

void GraphicComponentManager::DeletePtr()
{
    if (graphic_ptr != nullptr)
    {
        delete graphic_ptr;
        graphic_ptr = nullptr;
    }
}


void GraphicComponentManager::AddGraphic(GraphicComponent* lc)
{
    graphics.insert({ lc->GetOwner()->GetID(), lc});
}

void GraphicComponentManager::DeleteGraphic(GraphicComponent* c)
{
    string key = FindGraphic(c);

    if (key != "")
        graphics.erase(key);
}

void GraphicComponentManager::DeleteGraphic(string ID)
{
    GraphicComponent* tmp = FindGraphic(ID);
    this->graphics.erase(ID);

    //delete tmp;
}

const string GraphicComponentManager::FindGraphic(GraphicComponent* c)
{
    for (auto it = graphics.begin(); it != graphics.end(); it++)
    {
        if (it->second == c)
            return it->first;
    }

    return "";
}

GraphicComponent* GraphicComponentManager::FindGraphic(string ID)
{
    for (auto it = graphics.begin(); it != graphics.end(); it++)
    {
        GameObject* tmp = it->second->GetOwner();
        
        if (tmp->GetID() == ID)
            return it->second;
    }

    return nullptr;
}

void GraphicComponentManager::Update()
{
    for (auto it = graphics.begin(); it != graphics.end(); it++)
    {
        it->second->Update();
    }
}
